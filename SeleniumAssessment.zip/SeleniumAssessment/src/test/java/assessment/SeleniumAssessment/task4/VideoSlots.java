package assessment.SeleniumAssessment.task4;

import org.testng.annotations.Test;

import com.seleniumAssessment.setup.DriverSetup;
import com.seleniumAssessment.videoSlotsMethods.videoSlotsMethods;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class VideoSlots extends DriverSetup{

	videoSlotsMethods videoSlotsMethods ;
	
	@BeforeTest
	public void setUp() throws InterruptedException {
		
		initialization();
		videoSlotsMethods = new videoSlotsMethods();
	}

	@Test(priority =1)
	public void openAccount() throws InterruptedException {
		
		videoSlotsMethods.openAccount();
	}
	
	@Test(priority =2)
	public void login() throws InterruptedException {
		
		videoSlotsMethods.login();
	}

	@AfterTest
	public void afterTest() throws InterruptedException {
		
		Thread.sleep(3000);
		driver.quit();
	}

}
