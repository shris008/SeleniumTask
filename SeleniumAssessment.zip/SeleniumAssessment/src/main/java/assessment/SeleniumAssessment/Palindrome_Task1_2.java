package assessment.SeleniumAssessment;

public class Palindrome_Task1_2 {

	public static void main(String[] args) {

		String Endresult = "";

		String palidromeString = "NeverOddorEven";
		System.out.println("Given string is :"+palidromeString);
		int StringSize = palidromeString.length();

		for(int i =StringSize-1;i>= 0;i--)
		{
			Endresult = Endresult + palidromeString.charAt(i);
		}
		System.out.println("End resut is "+Endresult);
		if(Endresult.equalsIgnoreCase(palidromeString))
		{
			System.out.println("The given string is a palindrome");
		}
		else
		{
			System.out.println("The given string is not palindrome");
		}
	}
}


