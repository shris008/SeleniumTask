package assessment.SeleniumAssessment;

import java.util.Scanner;

public class MultiplierOf4Or6_Task1_1 {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter the numbers of array");  
		int sizeOfTheArray =  scanner.nextInt();

		int[] numberArray = new int[sizeOfTheArray];  

		System.out.println("Enter the numbers into the array");

		for(int i=0;i<sizeOfTheArray;i++)  
		{  

			numberArray[i]=scanner.nextInt(); 

		}  
		System.out.println("Entered number array");
		
		for(int i=0;i<sizeOfTheArray;i++)  
		{  

			System.out.println(numberArray[i]);  

		} 
		
		System.out.println("Return the numbers which is multiple of 4 or 6 or both");
		
		for(int i=0;i<sizeOfTheArray;i++)  
		{  

			if((numberArray[i]%4==0) && (numberArray[i]%6==0)) {
				
				System.out.println("Number "+numberArray[i]+" is multiple of both 4 and 6 ");
				
			} else if(numberArray[i]%4==0){
				
				System.out.println("Number "+numberArray[i]+" is multiple of 4 ");
				
			}else if(numberArray[i]%6==0){
				
				System.out.println("Number "+numberArray[i]+" is multiple of 6 ");
			}

		} 
		
	}

}
