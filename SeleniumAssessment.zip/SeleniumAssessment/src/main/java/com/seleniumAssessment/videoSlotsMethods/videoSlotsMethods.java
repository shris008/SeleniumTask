package com.seleniumAssessment.videoSlotsMethods;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.seleniumAssessment.setup.DriverSetup;


/**
 * @author shriyan supritha
 * 
 * This class contains the elements and methods related to VideoSlots.java class
 *
 */
public class videoSlotsMethods extends DriverSetup{
	
	@FindBy(xpath="//span[text()='Open Account']")
	WebElement openAccountBTN;
	
	@FindBy(id="email")
	WebElement emailField;
	
	@FindBy(id="password")
	WebElement passwordField;
	
	@FindBy(id="country")
	WebElement countryField;
	
	@FindBy(id="country_prefix")
	WebElement countryCodeField;
	
	@FindBy(id="mobile")
	WebElement mobileNumberField;
	
	@FindBy(id="privacy")
	WebElement privacyPolicy;
	
	@FindBy(id="conditions")
	WebElement termsConditions;
	
	@FindBy(id="submit_step_1")
	WebElement registerStep1;
	
	@FindBy(id="firstname")
	WebElement firstNameField;
	
	@FindBy(id="lastname")
	WebElement lastNameField;
	
	@FindBy(id="address")
	WebElement addressField;
	
	@FindBy(id="zipcode")
	WebElement zipCodeField;
	
	@FindBy(id="city")
	WebElement cityField;
	
	@FindBy(id="preferred_lang")
	WebElement languageField;
	
	@FindBy(id="birthyear")
	WebElement birthYearField;
	
	@FindBy(id="birthmonth")
	WebElement birthMonthField;
	
	@FindBy(id="birthdate")
	WebElement birthDateField;
	
	@FindBy(id="currency")
	WebElement currencyField;
	
	@FindBy(id="email_code")
	WebElement validationCode;
	
	@FindBy(id="eighteen")
	WebElement ageCheckBox;
	
	@FindBy(id="submit_step_2")
	WebElement registerStep2;
	
	@FindBy(id="close-registration-box")
	WebElement closeRegistrationBox;
	
	@FindBy(xpath="//span[text()='Log in']")
	WebElement loginBTN;
	
	@FindBy(id="lic-login-username-field")
	WebElement loginEmail;
	
	@FindBy(id="lic-login-password-field")
	WebElement loginPassword;
	
	@FindBy(xpath="//*[@id='lic-mbox-login-default']/div[2]/span")
	WebElement login;
	
	public videoSlotsMethods() {
		
		PageFactory.initElements(driver, this);
	}
	
	// this method is to open an account
	public void openAccount() throws InterruptedException {
		
		Thread.sleep(5000);
		openAccountBTN.click();
		Thread.sleep(3000);
		driver.switchTo().frame("mbox-iframe-registration-box");
		emailField.sendKeys("test2@abc.com");
		passwordField.sendKeys("Test@123");
		Select countryField1 = new Select(countryField);
		countryField1.selectByVisibleText(" India ( IN ) ");
		mobileNumberField.sendKeys("0123456778");
		privacyPolicy.click();
		termsConditions.click();
		registerStep1.click();
		Thread.sleep(3000);
		firstNameField.sendKeys("Supritha");
		lastNameField.sendKeys("Shriyan");
		addressField.sendKeys("abcdefghijkl");
		zipCodeField.sendKeys("576211");
		cityField.sendKeys("Bangalore");
		//Select languageField1 = new Select(languageField);
		//languageField1.selectByVisibleText(" English ");
		Select birthYearField1 = new Select(birthYearField);
		birthYearField1.selectByVisibleText(" 1994 ");
		Select birthMonthField1 = new Select(birthMonthField);
		birthMonthField1.selectByVisibleText(" October ");
		Select birthDateField1 = new Select(birthDateField);
		birthDateField1.selectByVisibleText(" 08 ");
		//Select currencyField1 = new Select(currencyField);
		//currencyField1.selectByVisibleText(" INR ");
		validationCode.sendKeys("1234");
		//scroll to particular element
		JavascriptExecutor js = (JavascriptExecutor)driver;
		/*js.executeScript("arguments[0].scrollIntoView(true);", ageCheckBox);
		ageCheckBox.click();
		//scroll to particular element
		JavascriptExecutor js1 = (JavascriptExecutor)driver;
		js1.executeScript("arguments[0].scrollIntoView(true);", registerStep2);
		registerStep2.click();*/
		Thread.sleep(3000);
		closeRegistrationBox.click();
		Thread.sleep(3000);
	}
	
	//this method is to login to registered account
	public void login() throws InterruptedException {
		
		loginBTN.click();
		loginEmail.sendKeys(prop.getProperty("email"));
		loginPassword.sendKeys(prop.getProperty("password"));
		
		Thread.sleep(3000);
		login.click();
		Thread.sleep(5000);
	}
}
