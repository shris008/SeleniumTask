package com.seleniumAssessment.setup;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * @author shriyan Supritha
 * 
 * this class is for driver setup 
 *
 */
public class DriverSetup {

	public static WebDriver driver;
	public static Properties prop;

	public DriverSetup() {
		try {
			prop = new Properties();
			FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+"/config.properties");

			prop.load(ip);
			
		} catch (FileNotFoundException e) {

			e.printStackTrace();
			
		}catch (IOException e) {

			e.printStackTrace();
			
		}
	}
	
	//launch url from specific browser
	public void initialization() throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/drivers/chromedriver.exe");
		System.setProperty("webdriver.chrome.siletOutput", "true");
		DesiredCapabilities cap = new DesiredCapabilities();
		ChromeOptions options = new ChromeOptions();
		options.setPageLoadStrategy(PageLoadStrategy.NONE);
		options.merge(cap);
		driver = new ChromeDriver(options);
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.get(prop.getProperty("url"));
		Thread.sleep(5000);
	}


}
